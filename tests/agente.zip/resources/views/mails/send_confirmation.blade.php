@component('mail::message')

# {{ __("¡Tu operación fue confirmada!") }}

Resumen de operacion



@endcomponent