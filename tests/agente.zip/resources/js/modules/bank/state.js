export default {
	banks: [],
}