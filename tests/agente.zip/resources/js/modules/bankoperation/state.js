export default {
	bankOperations: [],
}