export default {
	from: 0,
	to: 0,
	amount: 149,
	comission: 1,
	fromAccount: 0,
	toAccount: 0,
	/* If the client is not the owner */
	isMine: true,
	ownerName: null,
	accountNumber: null
}