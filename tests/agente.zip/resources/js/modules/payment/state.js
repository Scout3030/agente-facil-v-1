export default {
	from: 0,
	fromAccount: 0,
	to: 0,
	operation: 0,
	amount: 200,
	comission: 1,
	/* owner's - bussines's code and name  */
	code: null,
	name: null
}